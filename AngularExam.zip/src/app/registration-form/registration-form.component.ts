import { Component } from '@angular/core';
import { FormGroup ,FormControl,Validators} from '@angular/forms';

@Component({
  selector: 'app-registration-form',
  standalone: false,
  templateUrl: './registration-form.component.html',
  styleUrl: './registration-form.component.css'
})
export class RegistrationFormComponent {
  registrationForm:FormGroup;

  constructor(){
    this.registrationForm=new FormGroup({
      email: new FormControl('',[
        Validators.required,
        Validators.email,
      ]),

      password: new FormControl('',[
        Validators.required,
        Validators.minLength(8)
      ]),
    })
  }

  onSubmit(){
    if(this.registrationForm.valid){
     alert('Form Submitted:')
    }else{
      console.log('Form is invalid');
    }
  }

}
